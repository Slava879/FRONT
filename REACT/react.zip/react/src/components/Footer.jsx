import React from 'react'

function Footer() {
  return (
    <footer className="footer">
      <p className="logo">Logo</p>
      <nav className="footer-links">
        <a href="#" className="footer-link">О нас</a>
        <a href="#" className="footer-link">FAQ</a>
        <a href="#" className="footer-link">Юридические документы</a>
        <a href="#" className="footer-link">Поддержка</a>
      </nav>
    </footer>
  )
}

export default Footer