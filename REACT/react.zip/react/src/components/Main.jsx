import React from 'react'

import Profile from './Profile'

function Main() {
  return (
    <main>
      <section>
        <div>
          <p className="glav-section">Главный заголовок</p>
        </div>
        <Profile />
      </section>
    </main>
  )
}

export default Main