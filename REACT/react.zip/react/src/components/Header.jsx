import React from 'react'

function Header() {
  return (
    <header className="header">
      <p className="logo">LOGO</p>
      <div className="nav">
        <a className="login-link" href="#">Войти</a>
        <a className="register-link" href="#">Зарегистрироваться</a>
      </div>
    </header>
  )
}

export default Header