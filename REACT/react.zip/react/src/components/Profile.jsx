import React from 'react'

import {useState} from 'react'

function Profile() {
  const [Name, setName] = useState(false)
  const [ProfileName, setProfileName] = useState('')

  function SaveName() {
    const ProfileNameInput = document.querySelector('#InputName').value.trim()
    if (ProfileNameInput.length > 0) {
      setName(false)
      setProfileName(ProfileNameInput)
    }
  }

  return (
    <div className="profile">
      <div className="line">
        <div className="profile-info">
          <img className="profile-image" src="./img/profile_image.png" alt="" />
          <div className="profile-info-block">
            {!Name ? (
              <div id="NameSection">
                <span className="profile-name" id="profileName">{ProfileName}</span>
                <button className="EditNameButton" onClick={(Name) => setName((Name) => !Name)}>✏️</button>
              </div>
            ) : (
              <div id="EditSection">
                <div className="InputGroupName">
                  <input id="InputName" className="InputName" placeholder="Введите имя" />
                  <button id="PostName" className="PostNameButton" onClick={SaveName}>✓</button>
                </div>
              </div>
            )}
            <p className="profile-opisanie">Описание</p>
          </div>
        </div>

        <div className="profile-instrument-block">
          <span className="instrument-logo">Инструменты</span>
          <button className="EditToolsButton">✏️</button>
          <button className="HiddenToolsInput">✖️</button>
          <div className="instruments">
            <ul id="tools-list">
                <div className="InputGroup">
                  <input className="InputInstrument" id="InputInstrument" placeholder="Введите название инструмента"/>
                  <button id="AddInstrument" className="AddInstrument">+</button>
                </div>
            </ul>
          </div>
        </div>
      </div>

      <div className="profile-my-info">
        <p className="profile-my-info-logo">о себе</p>
        <p className="profile-my-info-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti, explicabo enim omnis maiores voluptatibus labore animi, perferendis tempora facere unde velit, similique ipsa tenetur impedit delectus exercitationem earum harum magni.</p>
      </div>
    </div>
  )
}

export default Profile